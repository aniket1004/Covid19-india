import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'

@Injectable({
  providedIn: 'root'
})
export class FetchDataService {

  //_URL = "https://api.covid19india.org/data.json"
  _URL = "https://api.covid19india.org/data.json"
  
  constructor(private httpclient : HttpClient) { }
  
  fetchInfo() {
    return this.httpclient.get(this._URL);
    //return this.httpclient.get(this._URL);;
  }

  fetchTableData() {
    return this.httpclient.get('https://api.covid19india.org/state_district_wise.json')
  }
}
