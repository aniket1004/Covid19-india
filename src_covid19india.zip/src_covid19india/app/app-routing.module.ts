import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { DistrictComponent } from './district/district.component';


const routes: Routes = [
   /* { path : '' , component: AppComponent},*/
    { path : 'district/:state' , component : DistrictComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
