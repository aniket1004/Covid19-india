import { Component, OnInit } from '@angular/core';
import { FetchDataService } from './fetch-data.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'covid19-india';
  data = []
  arr = []
  chartType : String;
  chartDatasets : Array<any>;
  chartLabels: Array<any>;
  chartColors: Array<any>;
  chartOptions: any;
  tableData : {};
  d = [];
  active: number;
  recover : number;
  decease : number;
  confirm : number;

  constructor (private dataservice : FetchDataService, public router:Router) {}

   ngOnInit ()  {
    
      this.dataservice.fetchInfo().subscribe(
        res => {
          this.data = res as []
          
          this.arr = [
            this.data['statewise'][0]['confirmed'],
            this.data['statewise'][0]['active'],
            this.data['statewise'][0]['recovered'],
            this.data['statewise'][0]['deaths']
          ] 
          this.chartType = 'doughnut';

              this.chartDatasets = [
                { data: this.arr,label: 'Covid-19 India' }
              ];
            
              this.chartLabels = ['Confirmed','Active','Recovered','Deceased'];
            
              this.chartColors = [
                {
                  backgroundColor: ['#FDB45C','#9933CC','#46BFBD','#F7464A'],
                  hoverBackgroundColor: ['#FFC870','#aa66cc','#5AD3D1','#FF5A5E'],
                  borderWidth: 2,
                }
              ];
            
              this.chartOptions = {
                responsive: true
              };
              let i =0
              for(i=1;i< this.data['statewise'].length;i++) 
              {
                
                this.d.push({
                  'no' : i,
                  'statecode' : this.data['statewise'][i].statecode, 
                  'state': this.data['statewise'][i].state , 
                  'confirmed': this.data['statewise'][i].confirmed,
                  'active' : this.data['statewise'][i].active,
                  'recovered' : this.data['statewise'][i].recovered,
                  'deceased' : this.data['statewise'][i].deaths,
                  'lastupdate' : this.data['statewise'][i].lastupdatedtime
              })
              }  
        },
        err => console.log(err)
      )
    }
       
}
