export class StateInfo {
    constructor(
        public name :String,
        public confirmed:number,
        public active : number,
        public recovered : number,
        public deceased : number ) {}
}