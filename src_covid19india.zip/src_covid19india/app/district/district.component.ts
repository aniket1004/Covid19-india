import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { FetchDataService } from '../fetch-data.service';
@Component({
  selector: 'app-district',
  templateUrl: './district.component.html',
  styleUrls: ['./district.component.css']
})
export class DistrictComponent implements OnInit {
  title :String;
  d = [];
  active: number;
  recover : number;
  decease : number;
  confirm : number;
  tableData = {}
  districtTable = []
  district = []
  current_confirmed = []
  current_active = []
  current_recovered = []
  current_death = []
  chartADatasets: Array<any>
  chartType :String
  chartLabels: Array<any>
  chartAColors: Array<any>
  chartOptions: any
  chartCDatasets: Array<any>
  chartCColors: Array<any>
  chartRDatasets: Array<any>
  chartRColors: Array<any>
  chartDDatasets: Array<any>
  chartDColors: Array<any>

  constructor(private route : ActivatedRoute , private dataservice : FetchDataService) { }

  ngOnInit(): void {
    this.route.paramMap.subscribe(params =>
      {
        this.title = params.get('state')
      }
    )

    this.dataservice.fetchTableData().subscribe(
      resp => {
            this.tableData = resp
            this.confirm = 0; this.active = 0 ;this.recover = 0 ;this.decease = 0;
            let i=0;
            for (let state in this.tableData)
            {
                if (state == this.title)
                {
                  for (let key in this.tableData[state])
                  {
                     if ( key === 'districtData')
                    {
                          for (let district in this.tableData[state][key])
                          {
                              this.districtTable.push(
                                {
                                  'district':district,
                                  'confirmed':this.tableData[state][key][district]['confirmed'],
                                  'active':this.tableData[state][key][district]['active'],
                                  'recovered':this.tableData[state][key][district]['recovered'],
                                  'deceased':this.tableData[state][key][district]['deceased'],
                                })
                                 
                          }
                        
                    }
                  
                }
                }
                this.active = 0;this.confirm=0;this.recover=0;this.decease=0;
            }
          this.districtTable = this.districtTable.sort((a,b)=>(a['active'] > b['active'])? -1:1);
          for (i=0;i<10;i++)
          {
            this.district.push(this.districtTable[i]['district'])
            this.current_active.push(this.districtTable[i]['active'])
            this.current_confirmed.push(this.districtTable[i]['confirmed'])
            this.current_recovered.push(this.districtTable[i]['recovered'])
            this.current_death.push(this.districtTable[i]['deceased'])
            
            
          }
          this.chartType = 'line';

  this.chartADatasets = [
    { data: this.current_active, label: 'Active' },
    ];

  this.chartLabels = this.district

  this.chartAColors = [
    {
      backgroundColor: 'rgba(105, 0, 132, .2)',
      borderColor: 'rgba(200, 99, 132, .7)',
      borderWidth: 2,
    }/*
    {
      backgroundColor: '#46BFBD',
      borderColor: 'rgba(200, 99, 132, .7)',
      borderWidth: 2,
    },
    {
      backgroundColor: '#F7464A',
      borderColor: 'rgba(0, 10, 130, .7)',
      borderWidth: 2,
    }
    */
  ];

  this.chartOptions = {
    responsive: true
  };

  this.chartCDatasets = [
    { data: this.current_confirmed, label: 'Confirmed' },
    ];
    this.chartCColors = [
      {
        backgroundColor: 'rgba(255, 235, 59, 0.2)',
        borderColor: 'rgba(200, 99, 132, .7)',
        borderWidth: 2,
      }
    ]
    this.chartRDatasets = [
      { data: this.current_recovered, label: 'Recovered' },
      ];
      this.chartRColors = [
        {
          backgroundColor: 'rgba(76, 175, 80, 0.2)',
          borderColor: 'rgba(0, 10, 130, .7)',
          borderWidth: 2,
        }
      ]

      this.chartDDatasets = [
        { data: this.current_death, label: 'Deaths' },
        ];
        this.chartDColors = [
          {
            backgroundColor: 'rgba(244, 67, 54, 0.3)',
            borderColor: 'rgba(200, 99, 132, .7)',
            borderWidth: 2,
          }
        ] 

         } ,
      erro => console.log(erro)
       
    );
    
  }
  

}
